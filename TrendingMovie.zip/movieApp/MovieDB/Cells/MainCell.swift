

import UIKit
import Kingfisher

class MainCell: UITableViewCell {
    
    public static let identifier: String = "MainCell"

    @IBOutlet weak var posterImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var desclabel: UILabel!
    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var ratindView: UIView!
    
    public var movie: MovieEntity.Movie? {
        didSet{
            if let movie = movie {
                let posterURL = URL(string:"https://image.tmdb.org/t/p/w500" + (movie.poster ?? ""))
                posterImage.kf.setImage(with: posterURL)
                titleLabel.text = movie.title
                desclabel.text = movie.releaseData
                rating.text = "\(String(describing: movie.rating))"
                
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        selectionStyle = .none
        posterImage.layer.cornerRadius = 12
        posterImage.layer.masksToBounds = true
        ratindView.layer.cornerRadius = 20
        ratindView.layer.masksToBounds = true
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
